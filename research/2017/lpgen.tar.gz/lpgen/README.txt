Generic term algebra generator for all-terms, random-terms and counting terms of
a given size.

swipl -s combgen.pro

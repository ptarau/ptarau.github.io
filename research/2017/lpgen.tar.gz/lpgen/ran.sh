swipl -s rangen.pro
